PostPath by 1stStep.ai — macOS developer preview 0.1.0

This is a developer preview for people who already have Node.js 20 or newer.
It is not a one-click installer. It is not signed or notarized.
macOS Gatekeeper will treat it as an unidentified developer. Do not disable Gatekeeper.

Fresh install:
1. Install Node.js 20+ from https://nodejs.org
2. Unzip this folder somewhere you can write.
3. Double-click "Open PostPath.command".
   Broker pilot: double-click "Open PostPath Pilot.command" instead.
   If macOS blocks it, right-click the command file and choose Open.
4. The first launch unpacks the app into ~/.postpath/app and runs npm install once.
5. In the desk:
   - Paste OAuth credentials → Save credentials
   - Register redirect URI: http://127.0.0.1:47831/oauth/callback
   - Connect accounts
   - Click Enable in Cursor → restart Cursor

Redirect URI for every developer console:
http://127.0.0.1:47831/oauth/callback

Relaunch:
Run "Open PostPath.command" again. When ~/.postpath/app matches this download, the launcher starts it without unpacking again.

Upgrade:
Quit PostPath. Unzip the newer developer preview and run its launcher. It sees the different build,
replaces ~/.postpath/app, and leaves your data in ~/.social-mcp alone.
Do not delete ~/.social-mcp.

Credentials:
The vault stays in ~/.social-mcp (override with SOCIAL_MCP_HOME).
Uninstalling or upgrading the app does not delete the vault.

Uninstall:
Quit PostPath. Delete this unzipped folder and delete ~/.postpath/app.
Leave ~/.social-mcp in place if you want saved connections later.

Node.js: 20+
Signed: no
Kind: developer preview
