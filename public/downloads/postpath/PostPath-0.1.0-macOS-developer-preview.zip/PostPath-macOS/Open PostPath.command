#!/bin/bash
# PostPath by 1stStep.ai — macOS developer preview 0.1.0
# Not a one-click installer. Requires Node.js 20+. Unsigned; do not disable Gatekeeper.
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="${HOME}/.postpath/app"
mkdir -p "${HOME}/.postpath"

open_nodejs() {
  if command -v open >/dev/null 2>&1; then
    open "https://nodejs.org" >/dev/null 2>&1 || true
  fi
}

require_node() {
  local detail="${1:-}"
  echo ""
  echo "PostPath needs Node.js 20 or newer."
  [ -n "$detail" ] && echo "$detail"
  echo "Download the LTS installer from https://nodejs.org"
  echo ""
  if command -v osascript >/dev/null 2>&1; then
    osascript -e 'display dialog "PostPath needs Node.js 20+.\nInstall from https://nodejs.org and try again." buttons {"OK"} default button 1 with title "PostPath"' >/dev/null 2>&1 || true
  fi
  open_nodejs
  exit 1
}

if ! command -v node >/dev/null 2>&1; then
  require_node "Node.js was not found on PATH."
fi

NODE_VER="$(node -v 2>/dev/null || true)"
NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]" 2>/dev/null || echo 0)"
if [ -z "$NODE_VER" ] || [ "${NODE_MAJOR}" -lt 20 ]; then
  require_node "Found ${NODE_VER:-unknown} — PostPath requires 20+."
fi

BUNDLE_BUILD="$(head -n 1 "${DIR}/postpath-app.build" 2>/dev/null | tr -d '[:space:]' || true)"
INSTALLED_BUILD="$(head -n 1 "${APP}/.postpath-build" 2>/dev/null | tr -d '[:space:]' || true)"

# Unpack into a staging folder first, so a failed unpack or npm install leaves the old app working.
# Only ~/.postpath/app is replaced. The data home (~/.social-mcp: db.json, master.key, pilot.json) is never touched.
stage_app() {
  local next="${HOME}/.postpath/app.next"
  rm -rf "${next}"
  mkdir -p "${next}"
  tar -xzf "${DIR}/postpath-app.tgz" -C "${next}" --strip-components=1
  (cd "${next}" && npm install --omit=dev)
  if [ -n "${BUNDLE_BUILD}" ]; then printf '%s\n' "${BUNDLE_BUILD}" > "${next}/.postpath-build"; fi
  rm -rf "${HOME}/.postpath/app.old"
  if [ -d "${APP}" ]; then mv "${APP}" "${HOME}/.postpath/app.old"; fi
  mv "${next}" "${APP}"
  rm -rf "${HOME}/.postpath/app.old"
}

if [ ! -f "${APP}/bin/social-mcp.js" ]; then
  echo "First run: unpacking PostPath developer preview 0.1.0 and installing dependencies..."
  stage_app
elif [ -n "${BUNDLE_BUILD}" ] && [ "${BUNDLE_BUILD}" != "${INSTALLED_BUILD}" ]; then
  echo "Update: installed app ${INSTALLED_BUILD:-unknown} differs from this download ${BUNDLE_BUILD}. Replacing the app files at ${APP}."
  echo "Your data home is left as it is."
  stage_app
else
  echo "Relaunch: using existing app at ${APP} (${INSTALLED_BUILD:-unknown})"
fi

cd "${APP}"
echo "Starting PostPath by 1stStep.ai developer preview 0.1.0 (Node ${NODE_VER})..."
echo "This is not a one-click installer. Node.js 20+ is required."
apply_pilot_env() {
  if [ -n "${SOCIAL_MCP_PILOT_MODE:-}" ]; then
    return
  fi
  local vault="${SOCIAL_MCP_HOME:-${HOME}/.social-mcp}"
  local file="${vault}/pilot.json"
  if [ -f "$file" ] && grep -Eq '"pilot_mode"[[:space:]]*:[[:space:]]*true' "$file"; then
    export SOCIAL_MCP_PILOT_MODE=1
    export SOCIAL_MCP_DRAFT_ONLY=1
    if [ -z "${SOCIAL_MCP_PUBLISH_MODE:-}" ]; then
      export SOCIAL_MCP_PUBLISH_MODE=mock
    fi
    echo "pilot.json is on: starting in pilot mode. Publish stays off."
  fi
}
apply_pilot_env

if [ "${POSTPATH_NO_OPEN:-}" = "1" ]; then
  exec node ./bin/social-mcp.js app --no-open
fi
exec node ./bin/social-mcp.js app
