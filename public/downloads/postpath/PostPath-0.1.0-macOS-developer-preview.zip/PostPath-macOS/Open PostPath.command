#!/bin/bash
# PostPath by 1stStep.ai — macOS developer preview 0.1.0
# Not a one-click installer. Requires Node.js 20+. Unsigned; do not disable Gatekeeper.
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="${HOME}/.postpath/app"
mkdir -p "${HOME}/.postpath"

open_nodejs() {
  if command -v open >/dev/null 2>&1; then
    open "https://nodejs.org" >/dev/null 2>&1 || true
  fi
}

require_node() {
  local detail="${1:-}"
  echo ""
  echo "PostPath needs Node.js 20 or newer."
  [ -n "$detail" ] && echo "$detail"
  echo "Download the LTS installer from https://nodejs.org"
  echo ""
  if command -v osascript >/dev/null 2>&1; then
    osascript -e 'display dialog "PostPath needs Node.js 20+.\nInstall from https://nodejs.org and try again." buttons {"OK"} default button 1 with title "PostPath"' >/dev/null 2>&1 || true
  fi
  open_nodejs
  exit 1
}

if ! command -v node >/dev/null 2>&1; then
  require_node "Node.js was not found on PATH."
fi

NODE_VER="$(node -v 2>/dev/null || true)"
NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]" 2>/dev/null || echo 0)"
if [ -z "$NODE_VER" ] || [ "${NODE_MAJOR}" -lt 20 ]; then
  require_node "Found ${NODE_VER:-unknown} — PostPath requires 20+."
fi

if [ ! -f "${APP}/bin/social-mcp.js" ]; then
  echo "First run: unpacking PostPath developer preview 0.1.0 and installing dependencies..."
  mkdir -p "${APP}"
  tar -xzf "${DIR}/postpath-app.tgz" -C "${APP}" --strip-components=1
  (cd "${APP}" && npm install --omit=dev)
else
  echo "Relaunch: using existing app at ${APP}"
fi

cd "${APP}"
echo "Starting PostPath by 1stStep.ai developer preview 0.1.0 (Node ${NODE_VER})..."
echo "This is not a one-click installer. Node.js 20+ is required."
if [ "${POSTPATH_NO_OPEN:-}" = "1" ]; then
  exec node ./bin/social-mcp.js app --no-open
fi
exec node ./bin/social-mcp.js app
