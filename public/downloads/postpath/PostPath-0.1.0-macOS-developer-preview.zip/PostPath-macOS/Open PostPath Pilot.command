#!/bin/bash
# Start the broker desk: topic picker, drafts, approve. Nothing is published.
export SOCIAL_MCP_PILOT_MODE=1
export SOCIAL_MCP_DRAFT_ONLY=1
export SOCIAL_MCP_PUBLISH_MODE=mock
DIR="$(cd "$(dirname "$0")" && pwd)"
exec "$DIR/Open PostPath.command"
