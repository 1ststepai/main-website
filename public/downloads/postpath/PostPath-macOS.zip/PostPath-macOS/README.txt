PostPath by 1stStep.ai — macOS

1. Install Node.js 20+ from https://nodejs.org
2. Double-click "Open PostPath.command"
   (First launch: right-click → Open if macOS blocks an unidentified developer)
3. In the desk: save OAuth credentials, connect accounts, Enable in Cursor

Redirect URI for every developer console:
http://127.0.0.1:47831/oauth/callback

Vault: ~/.social-mcp
App files: ~/.postpath/app
