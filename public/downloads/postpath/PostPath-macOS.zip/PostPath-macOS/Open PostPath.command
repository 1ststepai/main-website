#!/bin/bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="${HOME}/.postpath/app"
mkdir -p "${HOME}/.postpath"

if ! command -v node >/dev/null 2>&1; then
  osascript -e 'display dialog "Node.js 20+ is required for PostPath.\nInstall it from https://nodejs.org and try again." buttons {"OK"} default button 1 with title "PostPath"' || true
  open "https://nodejs.org"
  exit 1
fi

if [ ! -f "${APP}/bin/social-mcp.js" ]; then
  mkdir -p "${APP}"
  tar -xzf "${DIR}/postpath-app.tgz" -C "${APP}" --strip-components=1
  (cd "${APP}" && npm install --omit=dev)
fi

cd "${APP}"
exec node ./bin/social-mcp.js app
