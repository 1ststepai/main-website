PostPath by 1stStep.ai — Windows

1. Install Node.js 20+ from https://nodejs.org
2. Double-click Open-PostPath.bat
3. In the desk: save OAuth credentials, connect accounts, Enable in Cursor

Redirect URI for every developer console:
http://127.0.0.1:47831/oauth/callback

Vault: %USERPROFILE%\.social-mcp
App files: %USERPROFILE%\.postpath\app
