$ErrorActionPreference = "Stop"
$Dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$App = Join-Path $env:USERPROFILE ".postpath\app"

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host "Node.js 20+ is required. Install from https://nodejs.org and try again."
  Start-Process "https://nodejs.org"
  exit 1
}

New-Item -ItemType Directory -Force -Path (Join-Path $env:USERPROFILE ".postpath") | Out-Null
$entry = Join-Path $App "bin\social-mcp.js"
if (-not (Test-Path $entry)) {
  New-Item -ItemType Directory -Force -Path $App | Out-Null
  tar -xzf (Join-Path $Dir "postpath-app.tgz") -C $App --strip-components=1
  Push-Location $App
  npm install --omit=dev
  Pop-Location
}

Set-Location $App
node .\bin\social-mcp.js app
