# PostPath by 1stStep.ai - Windows developer preview 0.1.0
# Not a one-click installer. Requires Node.js 20+. Unsigned; do not disable SmartScreen.
$ErrorActionPreference = "Stop"
$Dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$App = Join-Path $env:USERPROFILE ".postpath\app"

function Show-NodeRequired {
  param([string]$Detail)
  Write-Host ""
  Write-Host "PostPath needs Node.js 20 or newer." -ForegroundColor Yellow
  if ($Detail) { Write-Host $Detail -ForegroundColor Yellow }
  Write-Host "Download the LTS installer from https://nodejs.org" -ForegroundColor Yellow
  Write-Host ""
  try { Start-Process "https://nodejs.org" } catch { }
}

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Show-NodeRequired "Node.js was not found on PATH."
  exit 1
}

try {
  $raw = (& node -v 2>$null)
  $major = [int](($raw -replace '^v', '').Split('.')[0])
} catch {
  Show-NodeRequired "Could not read the Node.js version."
  exit 1
}

if ($major -lt 20) {
  Show-NodeRequired "Found Node.js $raw - PostPath requires 20+."
  exit 1
}

New-Item -ItemType Directory -Force -Path (Join-Path $env:USERPROFILE ".postpath") | Out-Null
$entry = Join-Path $App "bin\social-mcp.js"
$Root = Join-Path $env:USERPROFILE ".postpath"
$bundleFile = Join-Path $Dir "postpath-app.build"
$installedFile = Join-Path $App ".postpath-build"
$BundleBuild = if (Test-Path -LiteralPath $bundleFile) { (Get-Content -LiteralPath $bundleFile -TotalCount 1).Trim() } else { "" }
$InstalledBuild = if (Test-Path -LiteralPath $installedFile) { (Get-Content -LiteralPath $installedFile -TotalCount 1).Trim() } else { "" }

# Unpack into a staging folder first so a failed unpack or npm install leaves the old app working.
# Only %USERPROFILE%\.postpath\app is replaced. The data home (.social-mcp: db.json, master.key, pilot.json) is never touched.
function Install-AppFiles {
  $next = Join-Path $Root "app.next"
  $old = Join-Path $Root "app.old"
  if (Test-Path -LiteralPath $next) { Remove-Item -LiteralPath $next -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $next | Out-Null
  tar -xzf (Join-Path $Dir "postpath-app.tgz") -C $next --strip-components=1
  if ($LASTEXITCODE -ne 0) { throw "Could not unpack postpath-app.tgz." }
  Push-Location $next
  npm install --omit=dev
  $npmCode = $LASTEXITCODE
  Pop-Location
  if ($npmCode -ne 0) { throw "npm install failed." }
  if ($BundleBuild) { Set-Content -LiteralPath (Join-Path $next ".postpath-build") -Value $BundleBuild }
  if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Recurse -Force }
  try {
    if (Test-Path -LiteralPath $App) { Move-Item -LiteralPath $App -Destination $old }
  } catch {
    throw "Close every PostPath window, then run the launcher again. The app folder is in use."
  }
  Move-Item -LiteralPath $next -Destination $App
  if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Recurse -Force }
}

if (-not (Test-Path -LiteralPath $entry)) {
  Write-Host "First run: unpacking PostPath developer preview 0.1.0 and installing dependencies..."
  Install-AppFiles
} elseif ($BundleBuild -and ($BundleBuild -ne $InstalledBuild)) {
  Write-Host "Update: installed app $InstalledBuild differs from this download $BundleBuild. Replacing the app files at $App."
  Write-Host "Your data home is left as it is."
  Install-AppFiles
} else {
  Write-Host "Relaunch: using existing app at $App ($InstalledBuild)"
}

function Enable-PilotFromFile {
  if ($env:SOCIAL_MCP_PILOT_MODE) { return }
  $vault = if ($env:SOCIAL_MCP_HOME) { $env:SOCIAL_MCP_HOME } else { Join-Path $env:USERPROFILE ".social-mcp" }
  $file = Join-Path $vault "pilot.json"
  if (-not (Test-Path -LiteralPath $file)) { return }
  $rawJson = Get-Content -LiteralPath $file -Raw
  if ($rawJson -match '"pilot_mode"\s*:\s*true') {
    $env:SOCIAL_MCP_PILOT_MODE = "1"
    $env:SOCIAL_MCP_DRAFT_ONLY = "1"
    if (-not $env:SOCIAL_MCP_PUBLISH_MODE) { $env:SOCIAL_MCP_PUBLISH_MODE = "mock" }
    Write-Host "pilot.json is on: starting in pilot mode. Publish stays off."
  }
}
Enable-PilotFromFile

Set-Location $App
Write-Host "Starting PostPath by 1stStep.ai developer preview 0.1.0 (Node $raw)..."
Write-Host "This is not a one-click installer. Node.js 20+ is required."
if ($env:POSTPATH_NO_OPEN -eq "1") {
  node .\bin\social-mcp.js app --no-open
} else {
  node .\bin\social-mcp.js app
}
exit $LASTEXITCODE
