# PostPath by 1stStep.ai — Windows developer preview 0.1.0
# Not a one-click installer. Requires Node.js 20+. Unsigned; do not disable SmartScreen.
$ErrorActionPreference = "Stop"
$Dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$App = Join-Path $env:USERPROFILE ".postpath\app"

function Show-NodeRequired {
  param([string]$Detail)
  Write-Host ""
  Write-Host "PostPath needs Node.js 20 or newer." -ForegroundColor Yellow
  if ($Detail) { Write-Host $Detail -ForegroundColor Yellow }
  Write-Host "Download the LTS installer from https://nodejs.org" -ForegroundColor Yellow
  Write-Host ""
  try { Start-Process "https://nodejs.org" } catch { }
}

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Show-NodeRequired "Node.js was not found on PATH."
  exit 1
}

try {
  $raw = (& node -v 2>$null)
  $major = [int](($raw -replace '^v', '').Split('.')[0])
} catch {
  Show-NodeRequired "Could not read the Node.js version."
  exit 1
}

if ($major -lt 20) {
  Show-NodeRequired "Found Node.js $raw — PostPath requires 20+."
  exit 1
}

New-Item -ItemType Directory -Force -Path (Join-Path $env:USERPROFILE ".postpath") | Out-Null
$entry = Join-Path $App "bin\social-mcp.js"
if (-not (Test-Path $entry)) {
  Write-Host "First run: unpacking PostPath developer preview 0.1.0 and installing dependencies..."
  New-Item -ItemType Directory -Force -Path $App | Out-Null
  tar -xzf (Join-Path $Dir "postpath-app.tgz") -C $App --strip-components=1
  Push-Location $App
  npm install --omit=dev
  Pop-Location
} else {
  Write-Host "Relaunch: using existing app at $App"
}

Set-Location $App
Write-Host "Starting PostPath by 1stStep.ai developer preview 0.1.0 (Node $raw)..."
Write-Host "This is not a one-click installer. Node.js 20+ is required."
if ($env:POSTPATH_NO_OPEN -eq "1") {
  node .\bin\social-mcp.js app --no-open
} else {
  node .\bin\social-mcp.js app
}
exit $LASTEXITCODE
