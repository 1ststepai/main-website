@echo off
setlocal
title PostPath by 1stStep.ai developer preview
cd /d "%~dp0"
echo.
echo  PostPath by 1stStep.ai developer preview 0.1.0
echo  Not a one-click installer. Checking Node.js 20+ and launching the desk...
echo  SmartScreen may warn because this preview is unsigned. Do not disable it.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Open-PostPath.ps1"
if errorlevel 1 (
  echo.
  echo  Something went wrong. Need Node 20+? https://nodejs.org
  echo.
  pause
)
