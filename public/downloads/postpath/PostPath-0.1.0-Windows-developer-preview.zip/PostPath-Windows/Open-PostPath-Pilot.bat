@echo off
setlocal
title PostPath pilot
cd /d "%~dp0"
set SOCIAL_MCP_PILOT_MODE=1
set SOCIAL_MCP_DRAFT_ONLY=1
set SOCIAL_MCP_PUBLISH_MODE=mock
echo.
echo  PostPath pilot. Topic picker, drafts, and approve. Nothing is published.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Open-PostPath.ps1"
if errorlevel 1 pause
